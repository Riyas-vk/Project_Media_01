package com.example.project_vehicle_service_01;

public class ServiceInterfaceManager {
 Formatter formatter;

    public Formatter getFormatter() {
        return formatter;
    }
}
